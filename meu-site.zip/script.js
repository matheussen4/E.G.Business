function mostrarMensagem() {
  document.getElementById("mensagem").innerText = "Parabéns! Você programou seu primeiro site 🎉";
}
